from setuptools import setup

setup(
    name='gandb_distributions',
    version='1.0',
    description='Gaussian and Binomial distributions',
    packages=['gandb_distributions'],
    author='Max Boguslavskiy',
    author_male='max.bogus@gmail.com',
    zip_safe=False)